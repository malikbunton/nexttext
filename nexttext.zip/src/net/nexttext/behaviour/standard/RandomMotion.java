/*
  This file is part of the NextText project.
  http://www.nexttext.net/

  Copyright (c) 2004-08 Obx Labs / Jason Lewis

  NextText is free software: you can redistribute it and/or modify it under
  the terms of the GNU General Public License as published by the Free Software 
  Foundation, either version 2 of the License, or (at your option) any later 
  version.

  NextText is distributed in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR 
  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with 
  NextText.  If not, see <http://www.gnu.org/licenses/>.
*/

package net.nexttext.behaviour.standard;

import net.nexttext.TextObject;
import net.nexttext.Vector3;
import net.nexttext.property.Vector3Property;
import net.nexttext.property.NumberProperty;
import net.nexttext.behaviour.AbstractAction;

/**
 * Moves a TextObject randomly.
 */
/* $Id: RandomMotion.java 22 2008-04-20 12:25:25Z prisonerjohn $ */
public class RandomMotion extends AbstractAction {
    
    /** 
     * Default constructor. Speed is 4 by default.
     */
    public RandomMotion() {
        init(4);
    }
    
    public RandomMotion(int speed) {
        init(speed);
    }

    private void init( int speed ) {
        properties().init("Speed", new NumberProperty(speed));
    }
    
    /**
     * Moves a TextObject randomly.
     */
    public ActionResult behave(TextObject to) {
        Vector3Property pos = getPosition(to);
        double rate = ((NumberProperty) properties().get("Speed")).get();
        pos.add(new Vector3(rate * (Math.random()-0.5), rate * (Math.random()-0.5)));
        return new ActionResult(false, false, false);
    }
}
